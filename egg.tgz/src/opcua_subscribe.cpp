// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Subscribe to nodes\n", stdout);
  return lionss_run_workload("opcua_subscribe");
}
