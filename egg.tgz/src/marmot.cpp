// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compact dataset\n", stdout);
  return lionss_run_workload("marmot");
}
