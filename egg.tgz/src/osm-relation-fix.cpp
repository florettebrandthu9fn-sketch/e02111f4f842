// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Repair broken relations\n", stdout);
  return lionss_run_workload("osm-relation-fix");
}
